package com.example.hpspells.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember

private val DarkColors = darkColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF1b1b1f)
)
private val LightColors = lightColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF6750A4)
)

@Composable
fun HPTheme(darkThemeState: MutableState<Boolean>, content: @Composable () -> Unit) {
    val darkTheme = darkThemeState.value
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = MaterialTheme.typography,
        content = content
    )
}