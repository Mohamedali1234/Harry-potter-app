package com.example.hpspells.data

data class Spell(
    val incantation: String,
    val name: String = incantation,
    val effect: String,
    val movie: String,
    val unforgivable: Boolean = false
)