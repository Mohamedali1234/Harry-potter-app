package com.example.hpspells

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // compute today's spell deterministically
        val all = com.example.hpspells.data.SpellRepository.spells
        val dateString = LocalDate.now().format(DateTimeFormatter.ISO_DATE)
        val seed = dateString.hashCode().toLong()
        val rnd = kotlin.random.Random(seed)
        val spell = all[rnd.nextInt(all.size)]
        NotificationHelper.showSpellOfDayNotification(context, spell.incantation, spell.effect)
    }
}