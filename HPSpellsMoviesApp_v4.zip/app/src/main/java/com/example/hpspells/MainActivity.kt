package com.example.hpspells

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.hpspells.data.Spell
import com.example.hpspells.data.SpellRepository
import com.example.hpspells.theme.HPTheme
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.random.Random

private const val PREFS = "hp_prefs"
private const val KEY_FAVORITES = "favorites_set"
private const val KEY_DARK = "dark_mode"
private const val KEY_NOTIF = "notif_enabled"

class MainActivity : ComponentActivity() {

    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { handleImportFavorites(it) }
    }

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { handleExportFavorites(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ensure notification channel exists
        NotificationHelper.createChannel(this)

        setContent {
            val context = LocalContext.current
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val darkModePref = prefs.getBoolean(KEY_DARK, false)
            val notifPref = prefs.getBoolean(KEY_NOTIF, true)
            val darkState = remember { mutableStateOf(darkModePref) }

            HPTheme(darkState) {
                val navController = rememberNavController()
                // read launch extra (if notification tapped)
                val launchInc = intent?.getStringExtra("open_spell") ?: ""
                NavHost(navController = navController, startDestination = "list") {
                    composable("list") {
                        SpellListScreen(
                            darkState = darkState,
                            onToggleTheme = {
                                prefs.edit().putBoolean(KEY_DARK, it).apply()
                            },
                            onExportFavorites = { exportLauncher.launch("favorites.json") },
                            onImportFavorites = { importLauncher.launch(arrayOf("application/json")) },
                            onToggleNotifications = { enabled ->
                                prefs.edit().putBoolean(KEY_NOTIF, enabled).apply()
                                if (enabled) scheduleDailyNotification(context) else cancelDailyNotification(context)
                            },
                            onOpen = { spell ->
                                val encodedInc = URLEncoder.encode(spell.incantation, StandardCharsets.UTF_8.toString())
                                navController.navigate("detail/$encodedInc")
                            },
                            launchInc = launchInc,
                            navController = navController
                        )
                    }
                    composable(
                        route = "detail/{incantation}",
                        arguments = listOf(navArgument("incantation"){ type = NavType.StringType })
                    ) { backStackEntry ->
                        val incantation = backStackEntry.arguments?.getString("incantation") ?: ""
                        val decoded = URLDecoder.decode(incantation, StandardCharsets.UTF_8.toString())
                        val spell = SpellRepository.spells.firstOrNull { it.incantation == decoded }
                        if (spell != null) {
                            SpellDetailScreen(spell = spell) { navController.popBackStack() }
                        } else {
                            Text("Spell not found")
                        }
                    }
                }
            }
        }

        // schedule notification at 9:00 AM if enabled
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_NOTIF, true)) scheduleDailyNotification(this)
    }

    private fun scheduleDailyNotification(context: Context) {
        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT>=23) PendingIntent.FLAG_IMMUTABLE else 0)
        // set 9:00 AM next occurrence
        val now = java.util.Calendar.getInstance()
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 9)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            if (before(now)) add(java.util.Calendar.DATE, 1)
        }
        alarmMgr.setInexactRepeating(AlarmManager.RTC_WAKEUP, target.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
    }

    private fun cancelDailyNotification(context: Context) {
        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT>=23) PendingIntent.FLAG_IMMUTABLE else 0)
        alarmMgr.cancel(pending)
    }

    private fun handleImportFavorites(uri: android.net.Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val text = input.bufferedReader().use { it.readText() }
                val set = mutableSetOf<String>()
                val cleaned = text.replace("[", "").replace("]", "").replace("\s".toRegex(), "").replace(""", "")
                if (cleaned.isNotBlank()) {
                    cleaned.split(",").forEach { if (it.isNotBlank()) set.add(it) }
                }
                val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                prefs.edit().putStringSet(KEY_FAVORITES, set).apply()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleExportFavorites(uri: android.net.Uri) {
        try {
            val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val set = prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
            contentResolver.openOutputStream(uri)?.use { out ->
                val json = set.joinToString(prefix = "[", postfix = "]") { ""$it"" }
                out.write(json.toByteArray())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpellListScreen(
    darkState: MutableState<Boolean>,
    onToggleTheme: (Boolean) -> Unit,
    onExportFavorites: () -> Unit,
    onImportFavorites: () -> Unit,
    onToggleNotifications: (Boolean) -> Unit,
    onOpen: (Spell) -> Unit,
    launchInc: String,
    navController: androidx.navigation.NavHostController
) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val favoritesSet = remember { mutableStateListOf<String>().apply {
        addAll(prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet())
    } }

    var query by remember { mutableStateOf("") }
    var showUnforgivableOnly by remember { mutableStateOf(false) }
    val all = remember { SpellRepository.spells }
    val dateString = remember { LocalDate.now().format(DateTimeFormatter.ISO_DATE) }

    // Random "Spell of the Day" deterministic for the date
    val spellOfTheDay = remember(dateString) {
        val seed = dateString.hashCode().toLong()
        val rnd = Random(seed)
        all[rnd.nextInt(all.size)]
    }

    // Highlight today spell incantation
    val todayInc = spellOfTheDay.incantation

    // if launched from notification, navigate
    LaunchedEffect(launchInc) {
        if (!launchInc.isNullOrBlank()) {
            val decoded = URLDecoder.decode(launchInc, StandardCharsets.UTF_8.toString())
            // try find matching spell and navigate
            val found = all.firstOrNull { it.incantation == decoded }
            if (found != null) {
                val encoded = URLEncoder.encode(found.incantation, StandardCharsets.UTF_8.toString())
                navController.navigate("detail/$encoded")
            }
        }
    }

    val filtered = derivedStateOf {
        all.filter {
            val q = query.trim().lowercase()
            val matchesQ = q.isBlank() || it.incantation.lowercase().contains(q) || it.effect.lowercase().contains(q) || it.movie.lowercase().contains(q)
            val matchesFilter = if (showUnforgivableOnly) it.unforgivable else true
            matchesQ && matchesFilter
        }
    }

    var selectedTab by remember { mutableStateOf(0) } // 0: All,1:Favorites,2:Filters,3:Settings

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("HP Spells (Movies)") },
                actions = {
                    IconButton(onClick = { darkState.value = !darkState.value; onToggleTheme(darkState.value) }) {
                        Icon(if (darkState.value) Icons.Default.DarkMode else Icons.Default.LightMode, contentDescription = "Toggle theme")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = selectedTab==0, onClick = { selectedTab=0 }, icon = { Icon(Icons.Default.List, contentDescription = null) }, label = { Text("All") })
                NavigationBarItem(selected = selectedTab==1, onClick = { selectedTab=1 }, icon = { Icon(Icons.Default.Favorite, contentDescription = null) }, label = { Text("Favorites") })
                NavigationBarItem(selected = selectedTab==2, onClick = { selectedTab=2 }, icon = { Icon(Icons.Default.FilterList, contentDescription = null) }, label = { Text("Filters") })
                NavigationBarItem(selected = selectedTab==3, onClick = { selectedTab=3 }, icon = { Icon(Icons.Default.Settings, contentDescription = null) }, label = { Text("Settings") })
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            // Search field and spell of the day
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("Search by spell, effect, or movie") },
                label = { Text("Search") }
            )

            Card(Modifier.padding(12.dp).fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Spell of the Day", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    Text(spellOfTheDay.incantation, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(spellOfTheDay.effect, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                    Text("Seen in: ${spellOfTheDay.movie}", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { onOpen(spellOfTheDay) }) { Text("Open") }
                    }
                }
            }

            when (selectedTab) {
                0 -> {
                    LazyColumn(
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(filtered.value) { index, spell ->
                            // Staggered animation using index
                            var visible by remember { mutableStateOf(false) }
                            LaunchedEffect(Unit) {
                                kotlinx.coroutines.delay(50L * index)
                                visible = true
                            }
                            AnimatedVisibility(
                                visible = visible,
                                enter = fadeIn(animationSpec = tween(300)) + slideInVertically(animationSpec = tween(300), initialOffsetY = { 40 }),
                                exit = fadeOut() + slideOutVertically()
                            ) {
                                SpellCardWithActionsV4(spell = spell, favoritesSet = favoritesSet, onFavoritesChanged = { saveFavorites(prefs, favoritesSet) }, onOpen = onOpen, onShare = { shareSpell(context, it) }, isHighlighted = (spell.incantation == todayInc))
                            }
                        }
                        if (filtered.value.isEmpty()) {
                            item { Text("No spells match your search.", modifier = Modifier.padding(12.dp)) }
                        }
                    }
                }
                1 -> {
                    val favSpells = all.filter { favoritesSet.contains(it.incantation) }
                    if (favSpells.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No favorites yet. Tap the star on any spell to save it.")
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            itemsIndexed(favSpells) { index, spell ->
                                var visible by remember { mutableStateOf(false) }
                                LaunchedEffect(Unit) {
                                    kotlinx.coroutines.delay(30L * index)
                                    visible = true
                                }
                                AnimatedVisibility(visible = visible, enter = fadeIn(animationSpec = tween(250)) + slideInVertically(initialOffsetY = { 30 }), exit = fadeOut()) {
                                    SpellCardWithActionsV4(spell = spell, favoritesSet = favoritesSet, onFavoritesChanged = { saveFavorites(prefs, favoritesSet) }, onOpen = onOpen, onShare = { shareSpell(context, it) }, isHighlighted = (spell.incantation == todayInc))
                                }
                            }
                        }
                    }
                }
                2 -> {
                    Column(Modifier.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Filters", style = MaterialTheme.typography.titleMedium)
                            TextButton(onClick = { showUnforgivableOnly = false }) { Text("Reset") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                            Checkbox(checked = showUnforgivableOnly, onCheckedChange = { showUnforgivableOnly = it })
                            Spacer(Modifier.width(8.dp))
                            Text("Show Unforgivable curses only")
                        }
                    }
                }
                3 -> {
                    Column(Modifier.padding(12.dp)) {
                        Text("Settings", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Enable daily 9:00 AM Spell notification", modifier = Modifier.weight(1f))
                            val notifEnabled = prefs.getBoolean(KEY_NOTIF, true)
                            Switch(checked = notifEnabled, onCheckedChange = {
                                onToggleNotifications(it)
                            })
                        }
                        Spacer(Modifier.height(12.dp))
                        Row {
                            Button(onClick = { onExportFavorites() }) { Text("Export Favorites (JSON)") }
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { onImportFavorites() }) { Text("Import Favorites (JSON)") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpellCardWithActionsV4(spell: Spell, favoritesSet: MutableList<String>, onFavoritesChanged: () -> Unit, onOpen: (Spell) -> Unit, onShare: (Spell) -> Unit, isHighlighted: Boolean) {
    val borderColor = if (isHighlighted) Color(0xFFFFD54F) else Color.Transparent
    ElevatedCard(
        onClick = { onOpen(spell) },
        modifier = Modifier
            .fillMaxWidth()
            .then(if (isHighlighted) Modifier.border(2.dp, borderColor) else Modifier)
            .shadow(if (isHighlighted) 8.dp else 2.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            // icon emoji based on spell type
            Text(getIconForSpell(spell), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(end = 12.dp))
            Column(Modifier.weight(1f)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(spell.incantation, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = {
                        if (favoritesSet.contains(spell.incantation)) {
                            favoritesSet.remove(spell.incantation)
                        } else {
                            favoritesSet.add(spell.incantation)
                        }
                        onFavoritesChanged()
                    }) {
                        Icon(if (favoritesSet.contains(spell.incantation)) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "Favorite")
                    }
                }
                Text(spell.effect, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                Text("First seen: " + spell.movie, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

fun getIconForSpell(spell: Spell): String {
    return when {
        spell.unforgivable -> "🔥"
        spell.incantation.lowercase().contains("sectum") || spell.incantation.lowercase().contains("crucio") -> "☠️"
        spell.incantation.lowercase().contains("accio") || spell.incantation.lowercase().contains("wingardium") -> "✨"
        spell.incantation.lowercase().contains("rictusempra") || spell.incantation.lowercase().contains("slap") -> "⚡"
        else -> "🔮"
    }
}

@Composable
fun SpellDetailScreen(spell: Spell, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text(spell.incantation) },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            // spark animation
            val infinite = rememberInfiniteTransition()
            val scale by infinite.animateFloat(
                initialValue = 0.9f,
                targetValue = 1.05f,
                animationSpec = infiniteRepeatable(tween(900), repeatMode = RepeatMode.Reverse)
            )
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(spell.incantation, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.scale(scale))
            }
            if (spell.unforgivable) {
                Text("⚠️ Unforgivable Curse", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
            }
            Text(spell.effect, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 12.dp))
            Divider(Modifier.padding(vertical = 16.dp))
            Text("First appearance: " + spell.movie, style = MaterialTheme.typography.bodyMedium)
        }
    }
}