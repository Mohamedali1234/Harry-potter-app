# HP Spells (Movies)

A tiny Android app (Jetpack Compose) that lists **Harry Potter movie spells** with explanations and first appearance.
- 🔍 Search by spell, effect, or movie
- 📱 Built with Material 3 + Navigation Compose
- 🧙 Spells are **movies-only**

## How to run
1. Open this folder in **Android Studio (Giraffe+ recommended)**.
2. Let Gradle sync; if Android Studio asks to update versions, accept.
3. Click **Run ▶️** on an emulator or device (minSdk 24).

## Project layout
```
app/
  src/main/java/com/example/hpspells/
    data/Spell.kt
    data/SpellRepository.kt
    theme/Theme.kt
    MainActivity.kt
  src/main/res/values/colors.xml
  src/main/res/values/themes.xml
  AndroidManifest.xml
build.gradle.kts (app)
build.gradle.kts (project)
settings.gradle.kts
```

> Note: Minimal gradle wrapper files are included; Android Studio can recreate the full wrapper automatically.

## Added features (updated)
- Dark / Light theme toggle (persistent)
- Random **Spell of the Day** (deterministic per date)
- Favorites (save spells) — persistent via SharedPreferences
- Filters page (e.g., show Unforgivable curses only)
- Share spell card (share text via other apps)
- Music playback: app will attempt to play `res/raw/theme.mp3` if you add it. **I cannot include copyrighted Harry Potter theme music**; add your own MP3 or a royalty-free track at `app/src/main/res/raw/theme.mp3` to enable music. A mute/unmute button is included.

### Adding a theme music file
Place an MP3 named `theme.mp3` into `app/src/main/res/raw/` (create `raw` folder). Example:
```
app/src/main/res/raw/theme.mp3
```
Recommended: use a royalty-free or self-created track. Do NOT include copyrighted John Williams recordings.



## v3 Improvements added by assistant
- Music system improved: play from bundled raw resource **or** downloaded file in internal storage (`files/theme.mp3`); added volume slider and play/pause controls.
- Settings screen: toggle autoplay, download an MP3 from a URL directly into app internal storage and play it.
- Export/Import favorites as JSON via system file picker (useful to migrate/share favorites).
- Minor UI improvements and a dedicated Settings tab.

### Notes & limitations
- The app downloads MP3 files into internal storage (`context.filesDir/theme.mp3`). It **does not** write into `res/raw` at runtime (that's not possible).
- I still can't provide copyrighted Harry Potter recordings. Use a royalty-free MP3 URL or your own file.
- Export/Import expects a simple JSON array like `["Accio","Expelliarmus"]`.
- If you want "share as image" (rendering a spell card to an image and sharing), I can add that next — it's a bit more involved because of FileProvider setup, but doable.



## v4 - UI polish, animations, icons, daily notification
- Removed music features entirely.
- Added animations to list and detail screens.
- Added emoji icons for spells (based on type).
- Daily notification scheduled at 9:00 AM local time; tapping opens the spell detail.
- Today's spell is highlighted in the list.
- Settings simplified: theme toggle + export/import favorites + notification toggle.

### Building an APK
I cannot build the APK in this environment. To generate a ready-to-install APK locally:
1. Open the project in Android Studio (Electric Eel+ recommended).
2. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
3. After build finishes, use Build > Locate to find the APK under `app/build/outputs/apk/debug/app-debug.apk` (or release if you sign it).
4. Install on your device (enable `Install from unknown sources`), or use `adb install`.

If you want I can guide you step-by-step to produce the APK on your machine or on a cloud CI runner (GitHub Actions) and show the workflow file to produce signed APKs automatically.
